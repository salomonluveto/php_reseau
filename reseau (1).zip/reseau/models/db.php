<?php
session_start();

try {
    $db = new PDO("mysql:host=localhost;dbname=reseau", "root", "");
    //echo "connexion réussie";
}
catch(PDOException $e) {
    echo $e;
}

$page = basename($_SERVER['SCRIPT_NAME']);

function acces($db) {
    if(!empty($_SESSION['user'])) {
        $id = $_SESSION['user'];

        $req = $db->prepare("SELECT * FROM users WHERE id = ?");
        $req->execute([$id]);
        $user = $req->fetch(); 

        if(empty($user)) {
            header('location:index.php');
        }
        else {
            return $user;
        }
    }
    elseif(!empty($_COOKIE['user'])) {
        $id = $_COOKIE['user'];
        $_SESSION['user'] = $id;

        $req = $db->prepare("SELECT * FROM users WHERE id = ?");
        $req->execute([$id]);
        $user = $req->fetch(); 

        if(empty($user)) {
            header('location:index.php');
        }
        else {
            return $user;
        }
    }
    else {
        header('location:index.php');
    }
}