<?php
require_once 'controllers/user.controller.php';

ob_start();
?>
                <div class="py-3 px-4 bg-white mt-4 text-secondary">
                    <h2 class="text-center py-2  text-black" style="font-family:georgian;">Créer un compte</h2>
            
                    <p class="text-center"><img width="50" src="https://www.facebook.com/images/fb_icon_325x325.png" alt=""></p>

                    <?php
                    if(isset($_COOKIE['erreur'])) {
                    ?>
                    <div class="alert alert-danger my-3"><?= $_COOKIE['erreur'] ?></div>
                    <?php
                    }

                    ?>
                    <hr>
                    <form action="" method="post" enctype="multipart/form-data">
                        
                        <div class="row">
                            <label for="email" class="col-md-4 fw-light">Nom :</label>
                            <div class="col-md-8">
                                <input type="text" required name="nom" class="form-control form-control-sm">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <label for="email" class="col-md-4 fw-light">Adresse Email :</label>
                            <div class="col-md-8">
                                <input type="email" required name="email" class="form-control form-control-sm">
                            </div>
                        </div>
                        

                        <div class="row mt-2">
                            <label for="email" class="col-md-4 fw-light">Mot de passe :</label>
                            <div class="col-md-8">
                            <input type="password" required name="password" class="form-control form-control-sm">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <label for="email" class="col-md-4 fw-light">Confirmer :</label>
                            <div class="col-md-8">
                            <input type="password" required  name="conf" class="form-control form-control-sm">
                            </div>
                        </div>

                        <div class="row mt-2 ">
                            <label for="email" class="col-md-4 fw-light">Photo :</label>
                            <div class="col-md-8">
                                <input type="file" name="photo">
                            </div>
                        </div>
                        
                        <p class="mt-3"><button type="submit" class="btn btn-primary">Créer</button></p>
                        <hr>
                        <p><a href="index.php" class="btn btn-success">Se connecter</a></p>
                    </form>
                </div>

<?php
$div_content = ob_get_contents();
ob_end_clean();
$title = "S'inscrire";
require_once "layouts/guess.php";
?>