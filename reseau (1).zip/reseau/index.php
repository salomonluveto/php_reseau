<?php
require_once 'controllers/user.controller.php';

ob_start();
?>
    <div class="py-3 px-4 bg-white mt-5 text-secondary">
        <h2 class="text-center py-2 text-black" style="font-family:georgian;">Se connecter</h2>
        <p class="text-center"><img width="50" src="https://www.facebook.com/images/fb_icon_325x325.png" alt=""></p>
        <hr>
        <?php
        if(isset($_COOKIE['erreur'])) {
        ?>
        <div class="alert alert-danger my-3"><?= $_COOKIE['erreur'] ?></div>
        <?php
        }

        ?>
        <form action="" method="post">
            
            <div class="row">
                <label for="email" class="col-md-4 fw-light">Adresse Email :</label>
                <div class="col-md-8">
                    <input type="text" name="email" class="form-control form-control-sm">
                </div>
            </div>

            <div class="row mt-2">
                <label for="email" class="col-md-4 fw-light">Mot de passe :</label>
                <div class="col-md-8">
                <input type="password" name="password" class="form-control form-control-sm">
                </div>
            </div>
            <div class="row mt-2">
                <label for="email" class="col-md-4 fw-light"></label>
                <div class="col-md-8">
                <input type="checkbox" name="remember"> Rester connecté
                </div>
            </div>
            
            <p><button type="submit" class="btn btn-primary">Se connecter</button></p>
            <hr>
            <p><a href="register.php" class="btn btn-success">Créer un nouveau compte</a></p>
        </form>
    </div>

<?php
    $div_content = ob_get_contents();
    $title = "Se connecter";
    ob_end_clean();
    require_once "layouts/guess.php";
?>