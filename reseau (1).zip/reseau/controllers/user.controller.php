<?php 
require_once 'models/db.php';

switch($page) {

    case 'index.php':

        if(!empty($_POST['email']) & !empty($_POST['password'])) {
            
            $email = trim($_POST['email']);
            $password = trim($_POST['password']);
            $password = md5($password);

            $req = $db->prepare("SELECT id FROM users WHERE email = ? AND password = ?");
            $req->execute([$email, $password]);
            $user = $req->fetch();

            if(!empty($user)) {
                if(isset($_POST['remember'])) {
                    setcookie("user", $user['id'], time()+(3600*24*7));
                }
                
                $_SESSION['user'] = $user['id'];
                
    
                header('location:journal.php');
            }
            else {
                setcookie('erreur', 'Email ou mot de passe incorrecte!', time()+10);

                header('location:index.php');
            }


            
        }

        break;
    case 'register.php':

        if(!empty($_POST['nom']) & !empty($_POST['email']) & 
            !empty($_POST['password']) & !empty($_POST['conf'])) {
                $nom = trim($_POST['nom']);
                $email = trim($_POST['email']);
                $password = trim($_POST['password']);
                $confirmation = trim($_POST['conf']);

                if($password == $confirmation) {
                    $password = md5($password);

                    if($_FILES['photo']['tmp_name']) {
                        $origine = $_FILES['photo']['tmp_name'];
                        $type = $_FILES['photo']['type'];
                        $extension = basename($type);
                        $name_file = time().".".$extension;
                        $destination = "files/profiles/$name_file";
                        
                        if(move_uploaded_file($origine, $destination)) {
                        
                        }
                
                    }
                    else {
                        $name_file = null;
                    }

                    $requete = $db->prepare("INSERT INTO users (nom, email, password, photo) VALUES (?, ?, ?, ?)");
                    if($requete->execute([$nom, $email, $password, $name_file])) {
                        
                        header('location:index.php');
                    }
                    else {
                        setcookie("erreur", "Echec d'inscription", time()+5);
                        header('location:register.php');
                    }   
                }
                else {
        setcookie("erreur", "Le mot de passe et la confirmation ne sont pas identiques", time()+5);
        header('location:register.php');
    }
}

        break;
    case 'mon_profil.php':

        break;

    case 'profil.php':

        break;
    default:
        
    break;
}