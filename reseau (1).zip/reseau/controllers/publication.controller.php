<?php 
require_once 'models/db.php';

switch($page) {

    case 'journal.php':
        $user = acces($db);
        if(!empty($_POST['content']) || !empty($_FILES['photo'])) {
            $content = trim($_POST['content'])??null;
            
            if($_FILES['photo']['tmp_name']) {
                $origine = $_FILES['photo']['tmp_name'];
                $type = $_FILES['photo']['type'];
                $extension = basename($type);
                $name_file = time().".".$extension;
                $destination = "files/publications/$name_file";
                
                if(move_uploaded_file($origine, $destination)) {
                
                }
        
            }
            else {
                $name_file = null;
            }

            $requete = $db->prepare("INSERT INTO publications (user_id, content, image) VALUES (?, ?, ?)");
            if($requete->execute([$user['id'], $content, $name_file])) {
                
                header('location:journal.php');
            }
            else {
                setcookie("erreur", "Echec de publication", time()+5);
                header('location:journal.php');
            }   
                
        }

        $req = $db->query("SELECT (SELECT count(*) FROM comments WHERE comments.publication_id = comments.id) as nb_comment, (SELECT count(*) FROM reactions WHERE reactions.publication_id = publications.id) as nb_reaction, publications.id, publications.content, publications.created_at, publications.image, users.nom FROM publications LEFT JOIN users ON publications.user_id = users.id ORDER BY id DESC");
        $publications = $req->fetchAll();

        break;
    case 'publication.php':
        $user = acces($db);
        if(!empty($_GET['id'])) {
            $id = (int)$_GET['id'];

            $req = $db->prepare("SELECT (SELECT count(*) FROM comments WHERE comments.publication_id = comments.id) as nb_comment, (SELECT count(*) FROM reactions WHERE reactions.publication_id = publications.id) as nb_reaction, publications.id, publications.content, publications.created_at, publications.image, users.nom FROM publications LEFT JOIN users ON publications.user_id = users.id WHERE publications.id = ?");
            $req->execute([$id]);

            $publication = $req->fetch();

            if(empty($publication)) {
                header('location:journal.php');
            }

            $req2 = $db->prepare("SELECT comments.id, comments.content, users.nom, users.photo, comments.created_at FROM comments LEFT JOIN users ON comments.user_id=users.id WHERE publication_id = ?");
            $req2->execute([$id]);

            $comments = $req2->fetchAll();

        }
        else {
            header('location:journal.php');
        }

        break;

    case 'profil.php':

        break;
    default:
        
    break;
}