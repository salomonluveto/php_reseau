<?php
require_once '../models/db.php';

$user = acces($db);

if(!empty($_POST['publication']) & !empty($_POST['statut']))  {
    $publication_id = (int)$_POST['publication'];
    $user_id = $user['id'];
    $statut = ($_POST['statut'] == 1)?1:0;

    $req = $db->prepare("INSERT INTO reactions (user_id, publication_id, statut) VALUES (?, ?, ?)");
    if($req->execute([$user_id, $publication_id, $statut])) {
        echo 'ok';
    }
    else {
        echo 'ko';
    }

}
