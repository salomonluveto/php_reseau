
<!-- Modal -->
<div class="modal fade" id="createPublication" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Faire une publication</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="" id="pubForm" enctype="multipart/form-data" method="post">
            <p>Contenu :<textarea class="form-control" name="content" id="" cols="30" rows="10"></textarea></p>
            <p>photo :<input type="file" class="form-control" name="photo" id=""></p>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
        <button type="submit" form="pubForm" class="btn btn-primary">Publier</button>
      </div>
    </div>
  </div>
</div>