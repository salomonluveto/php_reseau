<?php
require_once 'controllers/publication.controller.php';

    ob_start();
?>
<div>
  
    <div class="mb-5">

        <div class="bg-white px-2 py-3 shadow-sm">
            <div class="row">
                <div class="col-1">
                    <a href="profil.php" class="rounded-circle profil-user"  style="background-image:url(files/profiles/p2.jpeg);backgrou"></a>
                </div>
                <div class="col-11">
                    <p style="font-size:10px;"><b><?= $publication['nom'] ?></b><br><i class="text-grey" style="font-size:9px;">il y a 40 minutes</i></p>
                    
                </div>
            </div>
        <p><?= $publication['content'] ?></p>
            <p><img src="files/publications/<?= $publication['image'] ?>" alt="" class="img-fluid"></p>
            <div class="row">
                <div class="col"><a class="fw-lighter" href="like.php"><?= $publication['nb_reaction'] ?> réactions</a></div>
                <div class="col text-end"><a class="fw-lighter" href="#"><?= $publication['nb_comment'] ?> commentaires</a></div>
            </div>
            <hr>
            <div class="comments">
            <?php
                foreach($comments as $comment):
            ?>
                <div class="comment mt-2 bg-light px-2 pt-3">
                    <div class="row">
                        <div class="col-1">
                            <a href="profil.php" class="rounded-circle profil-user"  style="background-image:url(files/profiles/<?= $comment['photo'] ?>);backgrou"></a>
                        </div>
                        <div class="col-3">
                            <p style="font-size:10px;"><b><?= $comment['nom'] ?></b><br><i class="text-grey" style="font-size:9px;"><?= $comment['created_at'] ?></i></p>
                            
                        </div>
                        <div class="col-8">
                            <p style="font-size:10px;"><?= $comment['content'] ?></p>
                            
                        </div>
                    </div>
                </div>

                <?php 
                endforeach
                ?>

                <hr>

                <div class="row">
                    <div class="col-md-9">
                        <textarea name="" id="" cols="30" rows="1" class="form-control"></textarea>
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-success btn-sm">Commenter</button>
                    </div>
                </div>
                
            </div>
        </div>


    </div>
    

</div>
<?php
    $div_content = ob_get_contents();
    $title = "Journal";
    ob_end_clean();
    require_once "layouts/app.php";
?>               
         