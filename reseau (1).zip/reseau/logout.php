<?php 
session_start();
if(!empty($_COOKIE['user'])) {
    
    setcookie("user", "", time()-3600);
}
session_destroy();

header('location:index.php');