<?php
    ob_start();
?>
<div>
  
    <div class="mb-5">

        <div class="bg-white px-2 py-3 shadow-sm">
        <h6 class="text-center pt-2" style="font-family: Verdana, Geneva, Tahoma, sans-serif;">Réactions sur la publication</h6>
            <div class="comments">

                <div class="comment mt-2 bg-light px-2 pt-3">
                    <div class="row">
                        <div class="col-1">
                            <a href="profil.php" class="rounded-circle profil-user"  style="background-image:url(files/profiles/p2.jpeg);backgrou"></a>
                        </div>
                        <div class="col-10">
                            <p style="font-size:10px;"><b>Sarah Lemba</b><br><i class="text-grey" style="font-size:9px;">il y a 40 minutes</i></p>
                            
                        </div>
                        <div class="col-1">
                            <i class="fa-solid fa-thumbs-up"></i>
                        </div>
                        
                    </div>
                </div>

                <div class="comment mt-2 bg-light px-2 pt-3">
                    <div class="row">
                        <div class="col-1">
                            <a href="profil.php" class="rounded-circle profil-user"  style="background-image:url(files/profiles/p3.jpeg);backgrou"></a>
                        </div>
                        <div class="col-10">
                            <p style="font-size:10px;"><b>Sarah Lemba</b><br><i class="text-grey" style="font-size:9px;">il y a 40 minutes</i></p>
                            
                        </div>
                        <div class="col-1">
                            <i class="fa-solid fa-thumbs-down"></i>
                        </div>
                    </div>
                </div>

                <div class="comment mt-2 bg-light px-2 pt-3">
                    <div class="row">
                        <div class="col-1">
                            <a href="profil.php" class="rounded-circle profil-user"  style="background-image:url(files/profiles/p4.jpeg);backgrou"></a>
                        </div>
                        <div class="col-10">
                            <p style="font-size:10px;"><b>Sarah Lemba</b><br><i class="text-grey" style="font-size:9px;">il y a 40 minutes</i></p>
                            
                        </div>
                        <div class="col-1">
                            <i class="fa-solid fa-thumbs-up"></i>
                        </div>
                    </div>
                </div>
 
            </div>
        </div>


    </div>
    

</div>
<?php
    $div_content = ob_get_contents();
    $title = "Journal";
    ob_end_clean();
    require_once "layouts/app.php";
?>               
         