<?php
    ob_start();
?>
<div>
 

    <div class="mb-5">
        <div class="row">


            <div class="col-md-6 mt-2">
                <div class="card">
                    <img src="files/profiles/p2.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Sarah Lemba</h5>
                        <a href="profil.php" class="btn btn-primary btn-sm">Voir plus</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mt-2">
                <div class="card">
                    <img src="files/profiles/p3.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Merdi Lwambo</h5>
                        <a href="profil.php" class="btn btn-primary btn-sm">Voir plus</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mt-2">
                <div class="card">
                    <img src="files/profiles/p1.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Junior</h5>
                        <a href="profil.php" class="btn btn-primary btn-sm">Voir plus</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mt-2">
                <div class="card">
                    <img src="files/profiles/p5.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Jacques</h5>
                        <a href="profil.php" class="btn btn-primary btn-sm">Voir plus</a>
                    </div>
                </div>
            </div>



        </div>

    


    </div>
    


</div>
<?php
    $div_content = ob_get_contents();
    $title = "Journal";
    ob_end_clean();
    require_once "layouts/app.php";
?>               
         