<?php
require_once 'controllers/publication.controller.php';

    ob_start();
?>
<div>

    <div class="bg-white px-2 pb-3 shadow-sm">
        <h6 class="text-center pt-2" style="font-family: Verdana, Geneva, Tahoma, sans-serif;">Faire une publication <i class="fa-solid fa-bullhorn"></i></h6>

        <div class="row">
            <div class="col-1">
            <div class="rounded-circle profil-user"  style="background-image:url(files/profiles/<?= $user['photo'] ?>);"></div>
            </div>
            <div class="col-11">
                <input type="text" style="cursor:pointer;" disabled class="form-control"  data-bs-toggle="modal" data-bs-target="#createPublication">
            </div>
        </div>
    </div>

    <div class="mt-4 mb-5">
    <?php
    foreach($publications as $publication):

    ?>
        <div class="bg-white px-2 py-3 mt-3 shadow-sm">
            <div class="row">
                <div class="col-1">
                    <a href="profil.php" class="rounded-circle profil-user"  style="background-image:url(files/profiles/p1.jpeg);backgrou"></a>
                </div>
                <div class="col-11">
                    <p style="font-size:14px;"><b><?= $publication['nom'] ?></b><br><i class="text-grey" style="font-size:11px;"><?= $publication['created_at'] ?></i></p>
                    
                </div>
            </div>
            <p><?= $publication['content'] ?></p>
            <p><img src="files/publications/<?= $publication['image'] ?>" alt="" class="img-fluid"></p>
            <div class="row">
                <div class="col"><a class="fw-lighter" href="like.php"><?= $publication['nb_reaction'] ?> réactions</a></div>
                <div class="col text-end"><a class="fw-lighter" href="publication.php?id=<?= $publication['id'] ?>"><?= $publication['nb_comment'] ?> commentaires</a></div>
            </div>
            <hr>
            <div class="row action">
                <div class="col"><a href="publication.php?id=<?= $publication['id'] ?>"><i class="fa-solid fa-comment"></i> Commenter</a></div>
                <div class="col"><a publicationid="<?= $publication['id'] ?>" status="1"><i class="fa-solid fa-thumbs-up"></i> J'aime</a></div>
                <div class="col"><a publicationid="<?= $publication['id'] ?>" status="2"><i class="fa-solid fa-thumbs-down"></i> Je n'aime pas</a></div>
            </div>
        </div>

        <?php 
        endforeach
        ?>



    </div>
    


</div>
<?php
    $div_content = ob_get_contents();
    $title = "Journal";
    ob_end_clean();
    require_once "layouts/app.php";
?>               
         