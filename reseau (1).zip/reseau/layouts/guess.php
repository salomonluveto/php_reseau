<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title??null ?></title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">

                <?= $div_content ?>
            </div>
        </div>
    </div>
    
    <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>