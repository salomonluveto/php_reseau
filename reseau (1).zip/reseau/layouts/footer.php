<footer class="text-center py-3">
    <i class="fa fa-copyright" aria-hidden="true"></i>  Copyright 2024 ODC. All Right reserved
</footer>