
<header class="px-4 py-2 mb-4">
    <div class="row">
        <div class="logo text-white col-md-3" style="font-family:helvetica;">facebook<img src="" alt=""></div>
        <div class="col-md-3"><input placeholder="Rechercher les amis" class="form-control form-control-sm" type="search" name="" id=""></div>
        <nav class="col-md-6">
            <ul>
                <li><a href="journal.php" <?php if($page == "journal.php"): ?> class="active"<?php endif ?>><i class="fa-solid fa-house"></i> Journal</a></li>
                <li><a href="amis.php" <?php if($page == "amis.php"): ?> class="active"<?php endif ?>><i class="fa-solid fa-users"></i> Amis</a></li>
                <li><a href="mon_profil.php" <?php if($page == "mon_profil.php"): ?> class="active"<?php endif ?>><i class="fa-solid fa-user"></i> Mon profil (<?= $user['nom'] ?>)</a></li>
                <li><a href="logout.php"><i class="fa-solid fa-power-off"></i> Deconnexion</a></li>
            </ul>
        </nav>
    </div>
    

</header>