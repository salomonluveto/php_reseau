<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title??null ?></title>
    <script src="https://kit.fontawesome.com/675e30818a.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <style>
        footer {background:#3b5998;color:#fafafa;font-size:13px;font-variant:small-caps;}
        header {
            background:#3b5998;
            position:fixed;
            top:0;
            left:0;
            right: 0;
            z-index: 99999;
        }
        header ul {margin:0;padding:0;text-align:right;}
        header ul li {display:inline-block;}
        header ul li a {display:block;color:white;font-size:12px;text-decoration:none;padding:5px 10px;}
        header ul li a:hover {background-color: #fff;color:#3b5998;border-radius:4px;}
        header ul li a.active {background-color: #fff;color:#3b5998;border-radius:4px;}
        .dv_galery {padding: 1px;}
        .dv_galery div {height:70px;background-size:auto 100%;}
        .profil-user {display:inline-block;text-decoration:none;background-size:auto 100%;width:35px;height:35px;}
        .bg-white .action a {color:grey;font-size:14px;text-decoration:none;cursor:pointer;}
        .bg-white .action a.active {color:#3b5998;}
        .bg-white .action a:hover {background:silver;color:#444;padding:5px 10px;border-radius:7px;}
        .bg-white a.fw-lighter {color:inherit;font-size:12px;text-decoration:none;cursor:pointer;}
        .bg-white a.fw-lighter:hover, .bg-white a.fw-lighter.active {background:silver;color:#444;padding:5px 10px;border-radius:7px;}
        .dv_galery div {cursor: pointer;}
        #mgt {height: 80px;}
        #inline {
            position:fixed;bottom:0;right:50px;background:silver;padding:15px;
            box-shadow:1px 1px 7px #222;
        }
        #inline ul {list-style-type:none;margin:0;padding:0;}
        #inline ul li {border-top:1px solid rgba(5,5,5,0.1);padding:5px;font-variant:small-caps;font-size:13px;}
        #inline .boule {display:inline-block;height:8px;width:8px;background-color:green;border-radius:100%;}
    </style>
</head>
<body class="bg-light">
    <div id="mgt"></div>
    <?php require_once "layouts/menu.php"; ?>

    <div class="container">
        
        <div class="row">

            <div class="col-md-3">
                <div class="bg-white gallery px-3">
                    <h6 class="text-center pt-2" style="font-family: Verdana, Geneva, Tahoma, sans-serif;">Gallerie</h6>
                    <div class="row" onclick="location='gallery.php';">
                        <div class="col-md-4 dv_galery">
                            <div style="background-image:url(files/publications/b.jpeg);"></div>
                        </div>
                        <div class="col-md-4 dv_galery">
                            <div style="background-image:url(files/publications/a.jpeg);"></div>
                        </div>
                        <div class="col-md-4 dv_galery">
                            <div style="background-image:url(files/publications/ac.jpeg);"></div>
                        </div>
                        <div class="col-md-4 dv_galery">
                            <div style="background-image:url(files/publications/n.jpg);"></div>
                        </div>
                        <div class="col-md-4 dv_galery">
                            <div style="background-image:url(files/publications/o.jpg);"></div>
                        </div>
                        <div class="col-md-4 dv_galery">
                            <div style="background-image:url(files/publications/x.jpg);"></div>
                        </div>
                    </div>
                    <p class="text-center py-3"><a href="gallery.php" class="btn btn-success btn-sm">Voir plus</a></p>
                </div>

                <div class="bg-white gallery px-3 mt-5">
                    <h6 class="text-center pt-2" style="font-family: Verdana, Geneva, Tahoma, sans-serif;">Amis</h6>
                    <div class="row" onclick="location='amis.php';">
                        <div class="col-md-4 dv_galery amis">
                            <div style="background-image:url(files/profiles/p1.jpeg);"></div>
                        </div>
                        <div class="col-md-4 dv_galery">
                            <div style="background-image:url(files/profiles/p2.jpeg);"></div>
                        </div>
                        <div class="col-md-4 dv_galery">
                            <div style="background-image:url(files/profiles/p3.jpeg);"></div>
                        </div>
                        <div class="col-md-4 dv_galery">
                            <div style="background-image:url(files/profiles/p4.jpeg);"></div>
                        </div>
                        <div class="col-md-4 dv_galery">
                            <div style="background-image:url(files/profiles/p5.jpeg);"></div>
                        </div>
                        <div class="col-md-4 dv_galery">
                            <div style="background-image:url(files/profiles/p1.jpeg);"></div>
                        </div>
                    </div>
                    <p class="text-center py-3"><a href="amis.php" class="btn btn-success btn-sm">Voir plus</a></p>
                </div>



            </div>


            <div class="col-md-6">
                <?= $div_content ?> 
            </div>


            <div class="col-md-3">
                <div id="inline" class="">
                    <h6>Amis en ligne</h6>
                    <div>
                        <ul>
                            <li class="fw-light"><span class="boule"></span> Junior</li>
                            <li class="fw-light"><span class="boule"></span> Sarah</li>
                            <li class="fw-light"><span class="boule"></span> Merdi</li>
                            <li class="fw-light"><span class="boule"></span> Jacques</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require_once "includes/create_publication.php"; ?>
    <?php require_once "layouts/footer.php"; ?>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery-3.7.1.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.bg-white .action a').click(function() {
                
                const publication = $(this).attr('publicationid')
                const statut = $(this).attr('status')
                
                $.post('controllers/reaction.controller.php', {statut:statut, publication:publication}, function(data) {
                    alert(data)
                    if($.trim(data) == "ok") {
                        $(this).toggleClass('active');
                    }
                });
                
            })
            /*
            setInterval(() => {
                $.post('action.php', {inline:1}, function(data) {
                    const data2 = JSON.parse(data)
                    console.log(data2)
                    
                   
                });
            }, 5000);*/
        })
    </script>
</body>
</html>