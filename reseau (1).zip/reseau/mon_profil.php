<?php
    ob_start();
?>
<div>
    <div class="bg-white p-3 shadow-sm mb-3">
        <img src="files/profiles/p1.jpeg" style="width:100%;" alt="" class="img-fluid">
        <h3 class="text-center mt-3">Junior Tembo</h3>
    </div>

    <div class="bg-white px-2 pb-3 shadow-sm">
        <h6 class="text-center pt-2" style="font-family: Verdana, Geneva, Tahoma, sans-serif;">Faire une publication <i class="fa-solid fa-bullhorn"></i></h6>

        <div class="row">
            <div class="col-1">
                <div class="rounded-circle profil-user"  style="background-image:url(files/profiles/p1.jpeg);backgrou"></div>
            </div>
            <div class="col-11">
                <input type="text" style="cursor:pointer;" disabled class="form-control"  data-bs-toggle="modal" data-bs-target="#createPublication">
            </div>
        </div>
    </div>

    <div class="mt-4 mb-5">

    <div class="bg-white px-2 py-3 mt-3 shadow-sm">
            <div class="row">
                <div class="col-1">
                    <a href="profil.php" class="rounded-circle profil-user"  style="background-image:url(files/profiles/p1.jpeg);backgrou"></a>
                </div>
                <div class="col-11">
                    <p style="font-size:10px;"><b>Junior Tembo</b><br><i class="text-grey" style="font-size:9px;">il y a 40 minutes</i></p>
                    
                </div>
            </div>
            <p>Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <p><img src="files/publications/df.jpeg" alt="" class="img-fluid"></p>
            <div class="row">
                <div class="col"><a class="fw-lighter" href="like.php">5 personnes aiment</a></div>
                <div class="col text-end"><a class="fw-lighter" href="publication.php">10 commentaires</a></div>
            </div>
            <hr>
            <div class="row action">
                <div class="col"><a href="publication.php"><i class="fa-solid fa-comment"></i> Commenter</a></div>
                <div class="col"><a publicationid="1" status="1"><i class="fa-solid fa-thumbs-up"></i> J'aime</a></div>
                <div class="col"><a publicationid="1" status="2"><i class="fa-solid fa-thumbs-down"></i> Je n'aime pas</a></div>
            </div>
        </div>

        <div class="bg-white px-2 py-3 mt-3 shadow-sm">
            <div class="row">
                <div class="col-1">
                    <a href="profil.php" class="rounded-circle profil-user"  style="background-image:url(files/profiles/p1.jpeg);backgrou"></a>
                </div>
                <div class="col-11">
                    <p style="font-size:10px;"><b>Junior Tembo</b><br><i class="text-grey" style="font-size:9px;">il y a 40 minutes</i></p>
                    
                </div>
            </div>
            <p>Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <p><img src="files/publications/ac.jpeg" alt="" class="img-fluid"></p>
            <div class="row">
                <div class="col"><a class="fw-lighter" href="like.php">5 personnes aiment</a></div>
                <div class="col text-end"><a class="fw-lighter" href="publication.php">10 commentaires</a></div>
            </div>
            <hr>
            <div class="row action">
                <div class="col"><a href="publication.php"><i class="fa-solid fa-comment"></i> Commenter</a></div>
                <div class="col"><a publicationid="1" status="1"><i class="fa-solid fa-thumbs-up"></i> J'aime</a></div>
                <div class="col"><a publicationid="1" status="2"><i class="fa-solid fa-thumbs-down"></i> Je n'aime pas</a></div>
            </div>
        </div>

        <div class="bg-white px-2 py-3 mt-3 shadow-sm">
            <div class="row">
                <div class="col-1">
                    <a href="profil.php" class="rounded-circle profil-user"  style="background-image:url(files/profiles/p1.jpeg);"></a>
                </div>
                <div class="col-11">
                    <p style="font-size:10px;"><b>Junior Tembo</b><br><i class="text-grey" style="font-size:9px;">il y a 40 minutes</i></p>
                    
                </div>
            </div>
            <p>Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <p><img src="files/publications/b.jpeg" alt="" class="img-fluid"></p>
            <div class="row">
                <div class="col"><a class="fw-lighter" href="like.php">5 personnes aiment</a></div>
                <div class="col text-end"><a class="fw-lighter" href="publication.php">10 commentaires</a></div>
            </div>
            <hr>
            <div class="row action">
                <div class="col"><a href="publication.php"><i class="fa-solid fa-comment"></i> Commenter</a></div>
                <div class="col"><a publicationid="1" status="1"><i class="fa-solid fa-thumbs-up"></i> J'aime</a></div>
                <div class="col"><a publicationid="1" status="2"><i class="fa-solid fa-thumbs-down"></i> Je n'aime pas</a></div>
            </div>
        </div>



    </div>
    


</div>
<?php
    $div_content = ob_get_contents();
    $title = "Journal";
    ob_end_clean();
    require_once "layouts/app.php";
?>               
         